//
//  GameTable.swift
//  PokerGameServer
//
//  Created by Antoine roy on 25/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class GameTable: Table {
    
    var listPlayers: [Player] = []
    var sitPlace: [Bool] = []
    var pot: Int = 0
    var deck: Deck = Deck()
    var centralCards: [Card] = []
    
    var posDealer: Int = -1
    var posTab: Int = 0
    let sitTab: [Int] = [0, 4, 2, 7, 1, 5, 3, 6]
    var tabThread: [NSThread] = []
    var sb: Int?
    var letRead: Bool = true
    var nbFolded: Int = 0
    var runing: Bool = false
    var started: Bool = false
    
    func readClient(fdClient: AnyObject) {

        
        repeat {
            print("readClient fdClient = \(fdClient)")
            let client = findClientById((fdClient as? Int)!)
            if client.fd == nil {
                letRead = false
            } else {
                let data = client.read(1024*10, timeout: 1)
                if let d = data {
                    if let str=String(bytes: d, encoding: NSUTF8StringEncoding){
                        print("\(str)")
                        
                        let parser = XMLParser(xml: str, response: false)
                        if parser.cmd != "" {
                            checkCmdFromClient(parser, client: client)
                        }
                    }
                }
            }
            
        } while letRead == true
    
        print("-----------END OF THREAD READING CLIENT------------")
    }
    
    func readBetting(client: Player) {
        let data = client.read(1024*10)
        if let d = data {
            if let str=String(bytes: d, encoding: NSUTF8StringEncoding){
                print("\(str)")
                let parser = XMLParser(xml: str, response: false)
                if parser.cmd != "" {
                    checkCmdFromClient(parser, client: client)
                    return
                }
            }
        }
    }
    
    func findClientById(id: Int) -> Player {
        print("fiendClient id = \(id)")
        for p in listPlayers {
            print("trying to fing client with fd \(p.fd) et id \(id)")
            if Int(p.fd!) == id {
                return p
            }
        }
        
        print("error to find client")
        return Player()
    }
    
    func findClientBySit(sit: Int) -> Player? {
        for p in listPlayers {
            if p.sit! == sit {
                return p
            }
        }
        
        return nil
    }
    
    func removeClientById(fd: Int32) {
        var i = 0
        for p in listPlayers {
            print("cp p.fd == \(p.fd) and fd== \(fd)")
            if p.fd! == fd {
                listPlayers.removeAtIndex(i)
                print("deleting index \(i)\n remaining \(listPlayers.count)")

                break
            }
            i += 1
        }
    }
    
    func checkCmdFromClient(parser: XMLParser, client: Player) {
        
        switch parser.cmd! {
        case "sit":
            sitPlayer(parser, client: client)
            break
        case "leave":
            leaveTable(parser, client: client)
            break
        case "start":
            startGame(parser, client: client)
            break
        case "call":
            callAction(parser, client: client)
            break
        case "raise":
            raiseAction(parser, client: client)
            break
        case "fold":
            foldAction(parser, client: client)
            break
        default:
            break
        }
    }
    
    func foldAction(parser: XMLParser, client: Player) {
        for p in listPlayers {
            if p.sit! == client.sit! {
                p.folded = true
                p.cards.removeAll()
                nbFolded += 1
            }
        }
    }
    
    func raiseAction(parser: XMLParser, client: Player) {
        let bet = Int(parser.objects[0].object["moneyPut"]!)
        maxBet = bet!
        self.setMoneyPutForSit(client.sit!, value: bet!)
    }
    
    func callAction(parser: XMLParser, client: Player) {
        let bet = Int(parser.objects[0].object["moneyPut"]!)
        maxBet = bet!
        self.setMoneyPutForSit(client.sit!, value: bet!)
    }
    
    func leaveTable(parser: XMLParser, client: Player) {
        
        
        removeClientById(client.fd!)
        

        let maker: XMLMaker = XMLMaker(header: "leave")
        let obj: XMLObject = XMLObject(header: "player")
        
        client.send(str: maker.toResponse(obj.toResponse("done")))
        client.close()
    }
    
    func startGame(parser: XMLParser, client: Player) {
        if self.players >= 2 {
            letRead = false
            for t in tabThread {
                t.cancel()
            }
            tabThread.removeAll()
            gameProceed()
        } else {
            let maker: XMLMaker = XMLMaker(header: "start")
            let obj: XMLObject = XMLObject(header: "table")
            
            
            client.send(str: maker.toResponse(obj.toResponse("fail")))
        }
    }
    
    func sitPlayer(parser: XMLParser, client: Player) {
        let intPos: Int = Int(parser.objects[0].object["sit"]!)!
    
        print("list sit: \(sitPlace)")
        
        if self.sitPlace[intPos] == false {
            self.sitPlace[intPos] = true
            client.sit = intPos

            //orderPlayers(client)
            self.players = self.players! + 1
            
            //set reply sit 
            let maker: XMLMaker = XMLMaker(header: "sit")
            let obj: XMLObject = XMLObject(header: "table")

            
            
            client.send(str: maker.toResponse(obj.toResponse("done")))
            updateRequest()
        
        } else {
            let maker: XMLMaker = XMLMaker(header: "sit")
            let obj: XMLObject = XMLObject(header: "table")
            
            client.send(str: maker.toResponse(obj.toResponse("fail")))
        }
    }
    
    func orderPlayers(client: Player) {
        var newlist: [Player] = []
        
        var i = 0
        repeat {
            /*if client.sit! == sitTab[i] {
                i += 1
                newlist.append(client)
            }*/
            var j = 0
            for p in listPlayers {
                if p.sit! == sitTab[i] {
                    i += 1
                    newlist.append(p)
                    listPlayers.removeAtIndex(j)
                }
                j += 1
            }
        } while listPlayers.count > 0
        
        listPlayers = newlist
    }
    
    func startThread() {
        let range: Range<Int> = 0..<self.maxPlayers!
        for _ in range {
            self.sitPlace.append(false)
        }
        
        print("nb place of sit: \(sitPlace.count)")
        
        //let threadTable = NSThread.init(target: self, selector: #selector(GameTable.readingClients), object: nil)
        //print("before thread table launched")
        //threadTable.start()
        //print("after thread table launched")
    }
    
    func readingClients() {
            
        print("thread table is launched")
        
        repeat {
            
            // wait for more players
            print("\nwaiting for more players.\n")
            sleep(1)
            
        } while players < 2
        
        //game proceed
        gameProceed()
        //repeat {
        
            /*for p in listPlayers {
                print("je ne devrait pas etre ici")
                readClient(Int(p.fd!))
            
            }*/
        
        //} while true
    }
    
    func bettingRound(dealed: Bool = false) {
        var end = false

        var tabRead: [Int] = []
        let index = sitTab.indexOf(self.sb!)
        for i in index!..<sitTab.count {
            tabRead.append(sitTab[i])
        }
        if index! != 0 {
            for i in 0..<index! {
                tabRead.append(sitTab[i])
            }
        }
        
        runing = true
        
        print("betting round: \(tabRead)")

        repeat {
            for i in tabRead {
                if nbFolded == getNbPlayingPlayers() - 1 {
                    actualizePot()
                    return
                }
                let p = findClientBySit(i)
                print("try to find client sit \(i)")
                if p != nil && p?.isPlaying == true && p!.folded == false {
                    print("client found !")
                    self.setBettingTurnForSit((p?.sit!)!, value: true)
                    
                    if dealed == true {
                        sleep(1)
                        
                    }
                    
                    updateRequest(dealed)

                    print("before reading bet")
                    
                    readBetting(p!)
                    print("after reading bet")
                    self.setBettingTurnForSit((p?.sit!)!, value: false)
                }
            }
            
            var playing = 0
            var bet = 0
            for p in listPlayers {
                if p.moneyBet! == maxBet! || p.folded == true {
                    bet += 1
                } else if p.isPlaying == false {
                    playing += 1
                }
            }
            
            print("checking end betting : \(playing) + \(bet)")
            if (playing + bet) == listPlayers.count {
                end = true
            }
            
        } while end == false
        
        maxBet = 0
        animBet = true
        //requestEndBettingRound()
        updateRequest()
        //runing = false
        animBet = false
        actualizePot()
    }
    
    func actualizePot() {
        var total = 0
        for p in listPlayers {
            if p.moneyBet != nil {
                total += p.moneyBet!
            }
        }
        self.pot += total
    }
    
    func setMoneyPutForSit(sit: Int, value: Int) {
        for p in listPlayers {
            if p.sit! == sit {
                var m = 0
                if p.moneyBet != nil {
                    m = p.moneyBet!
                }
                p.money = p.money! - (value - m)
                p.moneyBet = value
                return
            }
        }
    }
    
    func requestEndBettingRound() {
        let maker: XMLMaker = XMLMaker(header: "endBetting")
        let obj: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "nothing")
        maker.addXML(obj)
        
        for p in listPlayers {
            p.send(str: maker.toString())
        }
    }
    
    func setBettingTurnForSit(sit: Int, value: Bool) {
        for p in listPlayers {
            if p.sit! == sit {
                p.bettingTurn = value
                return
            }
        }
    }
    
    func getNbPlayingPlayers() -> Int {
        var nb = 0
        
        for p in listPlayers {
            if p.isPlaying == true {
                nb += 1
            }
        }
        
        return nb
    }
    
    func gameProceed() {
        //dealing cards
        started = true
        for _ in 0..<3 {
            //listPlayers.sortInPlace({$0.sit < $1.sit})
            
            nbFolded = 0
            
            self.posDealer = getNextDealer()
            self.sb = getSmallBlind()
            let bb = getBigBlind()
        
            for p in listPlayers {
                p.isPlaying = true
                p.folded = false
                if p.sit! == posDealer {
                    p.isDealer = true
                } else {
                    p.isDealer = false
                }
                if p.sit! == sb {
                    p.smallBlind = true
                } else {
                    p.smallBlind = false
                }
                if p.sit! == bb {
                    p.bigBlind = true
                } else {
                    p.bigBlind = false
                }
            }
            
            let nbPlaying = getNbPlayingPlayers()
            
            centralCards.removeAll()
            self.deck.resetDeck()
            self.deck.shuffle()
            updateRequest()
            //sleep(1)
            dealingCards()
    
            maxBet = bigBlind
            
            bettingRound(true)
            resetMoneyBet()
            if nbFolded < nbPlaying - 1 {
                addCentralCard(3)
            }
            
            if nbFolded < nbPlaying - 1 {
                bettingRound()
            }
            resetMoneyBet()
            if nbFolded < nbPlaying - 1 {
                addCentralCard(1)
            }
            
            if nbFolded < nbPlaying - 1 {
                bettingRound()
            }
            resetMoneyBet()
            if nbFolded < nbPlaying - 1 {
                addCentralCard(1)
            }
            
            //sleep(3)
            if nbFolded < nbPlaying - 1 {
                bettingRound()
            }
            
                        //resultat
            var highest = 0
            var nbWinner = 0
            for p in listPlayers {
                if p.isPlaying == true && p.folded == false {
                    p.score = SolverResult.solver(p.cards, centrals: centralCards)
                    if highest < p.score {
                        highest = p.score
                        nbWinner = 0
                    }
                    if highest == p.score {
                        nbWinner += 1
                    }
                    
                }
            }
            
            
            for p in listPlayers {
                if p.score == highest{
                    p.money = p.money! + (pot / nbWinner)
                }
            }
            
            
            print("----------END GAME")
            resetMoneyBet()
            pot = 0
            maxBet = 0
            runing = false
            updateRequest()
        }
    }
    
    func resetMoneyBet() {
        for p in listPlayers {
            p.moneyBet = 0
        }
    }
    
    func getNextDealer() -> Int {
        
        if self.posDealer == -1 {
            
            return self.listPlayers[0].sit!
            
        }
        
        var i = 0
        for pos in sitTab {
            if pos == self.posDealer {
                break
            }
            i += 1
        }
        
        for val in i+1..<8 {
            if check(sitTab[val]) == true {
                return sitTab[val]
            }
        }
        
        for val in 0..<i+1 {
            if check(sitTab[val]) == true {
                return sitTab[val]
            }
        }
        
        return 0
    }
    
    
    
    func getSmallBlind() -> Int {
        var i = 0
        for pos in sitTab {
            if pos == self.posDealer {
                break
            }
            i += 1
        }
        
        for val in i+1..<8 {
            if check(sitTab[val]) == true {
                return sitTab[val]
            }
        }
        
        for val in 0..<i+1 {
            if check(sitTab[val]) == true {
                return sitTab[val]
            }
        }

        return 0
    }
    
    func getBigBlind() -> Int {
        var skipTime = 0
        var i = 0
        for pos in sitTab {
            if pos == self.posDealer {
                break
            }
            i += 1
        }
        
        repeat {
            
            for val in i+1..<8 {
                if check(sitTab[val]) == true {
                    skipTime += 1
                    if skipTime == 2 {
                        return sitTab[val]
                    }
                }
            }
            
            for val in 0..<i+1 {
                if check(sitTab[val]) == true {
                    skipTime += 1
                    if skipTime == 2 {
                        return sitTab[val]
                    }
                }
            }
            
        } while skipTime < 2
        
        return 0
    }
    
    func check(sit: Int) -> Bool {
        for p in listPlayers {
            if p.sit! == sit {
                return true
            }
        }
        return false
    }
    
    func dealingCards() {
        for p in listPlayers {
            p.cards.removeAll()
            p.cards.append(deck.deck[0])
            deck.deck.removeFirst()
            p.cards.append(deck.deck[0])
            deck.deck.removeFirst()
        }
        
        updateRequest()
    }
    
    func addCentralCard(nb: Int) {
       
        for _ in 0..<nb {
            
            centralCards.append(deck.deck[0])
            deck.deck.removeFirst()
            
        }
        
        updateRequest()
    }
    
    func centralRequest() {
        let maker: XMLMaker = XMLMaker(header: "central")

        var centrals: [String : String] = [:]
        var i = 0
        for c in centralCards {
            centrals["card\(i)"] = "\(c.nameStr)"
            i += 1
        }
        
        let obj: XMLObject = XMLObject(elems: centrals, header: "centralCards")
        maker.addXML(obj)
        for p in listPlayers {
            p.send(str: maker.toString())
        }
    }
    
    func addNewPlayer(client: TCPClient) {
        
        
        let p: Player = Player(client: client)
        p.money = 500
        self.listPlayers.append(p)
        //self.players = self.players! + 1
        letRead = true
        //let intFd = Int(p.fd!)
        let toto = p.fd?.toIntMax()
        //print("\nbefore start thread id = \(intFd) and \(toto!) and \(Int(toto!))")

        let readingThread = NSThread.init(target: self, selector: #selector(GameTable.readClient(_:)), object: Int(toto!))
        tabThread.append(readingThread)
        tabThread[tabThread.count - 1].start()
        //readingThread.start()
    }
    
    func updateRequest(dealed: Bool = false) {
        for p in listPlayers {
            let maker: XMLMaker = XMLMaker(header: "update")
            var (dic, tabObj) = self.getObjectToDic()
            
            if dealed == true {
                dic["dealed"] = "1"
            }
            if runing == true {
                dic["running"] = "1"
            }
            if started == true {
                dic["started"] = "1"
            }
            
            let obj: XMLObject = XMLObject(elems: dic, header: "table")
            obj.objects = tabObj
            
            maker.addXML(obj)
            p.send(str: maker.toString())
        }
    }
    
    func getObjectToDic() -> ([String : String], [XMLObject]) {
        var dic = self.getDicObject()
        
        dic["pot"] = "\(self.pot)"
        
        var tabObj: [XMLObject] = []
        for p in listPlayers {
            if p.sit != nil && p.sit! != -1 {
                tabObj.append(XMLObject(elems: p.getDicObject(), header: "player"))
            }
        }
        
        var centrals: [String : String] = [:]
        var i = 0
        for c in centralCards {
            centrals["card\(i)"] = "\(c.nameStr)"
            i += 1
        }
        if centrals.isEmpty == false {
            tabObj.append(XMLObject(elems: centrals, header: "centralCards"))
        }
        print("get object to dic: nb player \(listPlayers.count) and content dic \(tabObj.count)")
        return (dic, tabObj)
    }
    
    func deleteAllClient() {
        for p in listPlayers {
            p.close()
        }
        listPlayers.removeAll()
    }
    
}
