//
//  Card.swift
//  PokerGameServer
//
//  Created by Antoine roy on 28/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Cocoa

class Card: NSObject {

    var nameStr: String = ""
    var number: String = ""
    var type: String = ""
    
    override init() {
        super.init()
    }
    
    init(name: String) {
        super.init()
        
        self.nameStr = name
    }
    
    init(number: String, type: String) {
        super.init()
        self.number = number
        self.type = type
        self.nameStr = "\(number)_of_\(type)"
    }
    
    init(object: XMLObject) {
        
        if let name = object.object["name"] {
            self.nameStr = name
        }
    }
    
    func toDictionary() -> [String : String] {
        var dic: [String : String] = [:]
    
        dic["name"] = nameStr
        
        return dic
    }
    
    func toXML(first: Bool) -> XMLObject {
        var header: String = "card1"
        
        if first == false {
            header = "card2"
        }
        let obj: XMLObject = XMLObject(elems: self.toDictionary(), header: header)
        
        return obj
    }
    
}
