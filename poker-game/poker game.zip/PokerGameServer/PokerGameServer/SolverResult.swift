//
//  SolverResult.swift
//  PokerGameServer
//
//  Created by Antoine roy on 15/08/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Cocoa

class SolverResult: NSObject {

    static let value: [String : Int] = ["2":1, "3":2, "4":3, "5":4, "6":5, "7":6, "8":7, "9":8, "10":9, "jack":10, "queen":11, "king":12, "ace":13]
    static let type: [String : Int] = ["diamonds":1, "hearts":2, "clubs":3, "spades":4]
    
    static let ISONEPAIR = 100
    static let ISTWOPAIR = 250
    static let ISTHREEKIND = 3150
    static let ISSTRAIGHT = 6850
    static let ISFLUSH = 42000
    static let ISFULLHOUSE = 110000
    static let ISFOURKIND = 1400000
    static let ISSTRAIGHTFLUSH = 3100000
    static let ISROYALFLUSH = 40000000
    
    static var score = 0
    
    class func royalFlush(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        var color: Int = 0
        
        for item in tab {
            counter[item.1] = (counter[item.1] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value >= 5 {
                color = key
            }
        }
        
        if color != 0 {
            var cp: [Int] = []
            
            for item in tab {
                if item.1 == color && cp.contains(item.0) == false {
                    cp.append(item.0)
                }
            }
            
            cp.sortInPlace{$0 > $1}
            if cp.count >= 5 && cp[0] == 13 && cp[1] == 12 && cp[2] == 11 && cp[3] == 10 && cp[4] == 9 {
                score = ISROYALFLUSH
                return true
            }
            
        }
        
        return false
    }
    
    class func straightFlush(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        var color: Int = 0
        
        for item in tab {
            counter[item.1] = (counter[item.1] ?? 0) + 1
        }

        for (key, value) in counter {
            if value >= 5 {
                color = key
            }
        }
        
        if color != 0 {
            var cp: [Int] = []
            var nbStraight = 0
            
            for item in tab {
                if item.1 == color && cp.contains(item.0) == false {
                    cp.append(item.0)
                }
            }
            
            cp.sortInPlace{$0 < $1}
            var save = -1
            for i in 1..<cp.count {
                if cp[i - 1] == (cp[i] + 1) {
                    nbStraight += 1
                    save = cp[i]
                } else {
                    nbStraight = 0
                }
            }
            
            if nbStraight >= 4 {
                score = ISSTRAIGHTFLUSH * save
                return true
            }
        }
        
        return false
    }
    
    class func fourOfKind(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        
        for item in tab {
            counter[item.0] = (counter[item.0] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value == 4 {
                score = ISFOURKIND * key
                var cp: [(Int, Int)] = []
                for item in tab {
                    
                    if item.0 != key {
                        cp.append(item)
                    }
                }
                let res = highCard(cp, nb: 1)
                score += res[0].0
                return true
            }
        }
        
        return false
    }
    
    class func fullHouse(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        var pair = 0
        var triple = 0
        var savePair: [Int] = []
        var saveTriple: [Int] = []
        
        for item in tab {
            counter[item.0] = (counter[item.0] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value == 2 {
                pair += 1
                savePair.append(key)
            } else if value == 3 {
                triple += 1
                saveTriple.append(key)
            }
        }
        
        if pair > 0 && triple > 0 {
            if savePair.count > 1 {
                savePair.sortInPlace{$0 > $1}
            }
            if saveTriple.count > 1 {
                saveTriple.sortInPlace{$0 > $1}
            }
            
            score = (ISFULLHOUSE * savePair[0]) + (ISFULLHOUSE * saveTriple[0])
            return true
        }
        
        return false
    }
    
    class func flush(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        var color = false
        var keySave = 0
        
        for item in tab {
            counter[item.1] = (counter[item.1] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value == 5 {
                color = true
                keySave = key
            }
        }
        
        
        if color == true {
            for (key, value) in tab {
                if value == keySave {
                    score = (ISFLUSH * key)
                    return true
                }
            }
            
        }
        
        return false
    }
    
    class func straight(tab: [(Int, Int)]) -> Bool {
        var cp: [Int] = []
        var nbStraight = 0
        
        for item in tab {
            if cp.contains(item.0) == false {
                cp.append(item.0)
            }
        }
        
        cp.sortInPlace{$0 < $1}
        var save = -1
        for i in 1..<cp.count {
            if cp[i - 1] == (cp[i] + 1) {
                nbStraight += 1
                save = cp[i]
            } else {
                nbStraight = 0
            }
        }
        
        if nbStraight >= 4 {
            score = ISSTRAIGHT * save
            return true
        }
        
        return false
    }
    
    class func threeOfKind(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        var nb = 0
        var saves: [Int] = []
        
        for item in tab {
            counter[item.0] = (counter[item.0] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value == 3 {
                nb += 1
                saves.append(key)
            }
        }
        
        if nb > 0 {
            
            var cp: [(Int, Int)] = []
            if saves.count > 1 {
                saves.sortInPlace{$0 > $1}
            }
            score = ISTHREEKIND * saves[0]
            
            for item in tab {
                if item.0 != saves[0] {
                    cp.append(item)
                }
            }
            let res = highCard(cp, nb: 2)
            for item in res {
                score += item.0
            }
            return true
        }
        
        return false
    }
    
    class func twoPair(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        var nb = 0
        var saves: [Int] = []
        
        
        for item in tab {
            counter[item.0] = (counter[item.0] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value == 2 {
                nb += 1
                saves.append(key)
            }
        }
        
        if nb >= 2 {
            
            var cp: [(Int, Int)] = []
            saves.sortInPlace{$0 > $1}
            score = ISTWOPAIR * saves[0] + ISTWOPAIR * saves[1]
            
            for item in tab {
                
                if item.0 != saves[0] && item.0 != saves[1] {
                    cp.append(item)
                }
            }
            let res = highCard(cp, nb: 1)
            score += res[0].0
            return true
        }
        
        return false
    }
    
    class func onePair(tab: [(Int, Int)]) -> Bool {
        var counter: [Int : Int] = [:]
        
        for item in tab {
            counter[item.0] = (counter[item.0] ?? 0) + 1
        }
        
        for (key, value) in counter {
            if value == 2 {
                score = ISONEPAIR * key
                var cp: [(Int, Int)] = []
                for item in tab {
                    if item.0 != key {
                        cp.append(item)
                    }
                }
                let res = highCard(cp, nb: 3)
                for item in res {
                    score += item.0
                }
                return true
            }
        }
        
        return false
    }
    
    class func highCard(cards: [(Int, Int)], nb: Int) -> [(Int, Int)] {
        var cp = cards.sort{$0.0 > $1.0}
        print("high card sorted... \(cp)")
        var ret: [(Int, Int)] = []
        var cpNb = nb
        if cards.count < nb {
            cpNb = cards.count
        }
        for i in 0..<cpNb {
            ret.append(cp[i])
        }
        return ret
    }
    
    class func addAllCards(tab: [(Int, Int)]) {
        var ret = 0
        for item in tab {
            ret += item.0
        }
    }
    
    class func cutCard(card: Card) -> (Int, Int) {
        var tab: [String] = card.nameStr.characters.split{$0 == "_"}.map(String.init)
        let v: Int = value[tab[0]]!
        let t: Int = type[tab[2]]!
        return (v, t)
    }
    
    class func solver(pCards: [Card], centrals: [Card]) -> Int {
        score = 0
        var tabCut: [(Int, Int)] = []
        for card in pCards {
            tabCut.append(cutCard(card))
        }
        for card in centrals {
            tabCut.append(cutCard(card))
        }
        
        if royalFlush(tabCut) == true {
            print("is Royal flush with score of \(score)")
            return score
        } else if straightFlush(tabCut) == true {
            print("is straight flush with score of \(score)")
            return score
        } else if fourOfKind(tabCut) == true {
            print("is four of kind with score of \(score)")
            return score
        } else if fullHouse(tabCut) == true {
            print("is full house with score of \(score)")
            return score
        } else if flush(tabCut) == true {
            print("is flush with score of \(score)")
            return score
        } else if straight(tabCut) == true {
            print("is stright with score of \(score)")
            return score
        } else if threeOfKind(tabCut) == true {
            print("is three of kind with score of \(score)")
            return score
        } else if twoPair(tabCut) == true {
            print("is two pair with score of \(score)")
            return score
        } else if onePair(tabCut) == true {
            print("is one pair with score of \(score)")
            return score
        } else {
            let res = highCard(tabCut, nb: 5)
            for item in res {
                score += item.0
            }
            print("is high card with score of \(score)")
            return score
        }
    }
}
