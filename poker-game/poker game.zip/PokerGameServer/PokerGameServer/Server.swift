//
//  Server.swift
//  PokerGameServer
//
//  Created by Antoine roy on 18/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class Server: TCPServer {

    var tables: [GameTable] = []
    var nbTableCreated: Int = 0
    
    func launchServer(ip: String, port: Int) {
        self.addr = ip
        self.port = port
        
        let (success, msg) = self.listen()
        if success {
            while true {
                if let client: TCPClient = self.accept() {
                    let threadClient = NSThread.init(target: self, selector: #selector(Server.threadFirstReadClient), object: client)
                    threadClient.start()
                }
            }
        } else {
            print(msg)
        }
    }
    
    func closeServer() {
        print(self.close())
    }
    
    @objc func threadFirstReadClient(sender: AnyObject) {
        
        var lastCmd: String = ""
        
        repeat {
            let data = (sender as! TCPClient).read(1024*10)
            if let d = data {
                if let str = String(bytes: d, encoding: NSUTF8StringEncoding){
                    
                    let parser = XMLParser(xml: str, response: false)
                    if parser.cmd != "" {
                        checkActionClient(parser, client: (sender as! TCPClient))
                    }
                    lastCmd = parser.cmd!
                }
            } else {
                print("fail read")
            }
            
        } while lastCmd != "join"
    }
    
    func doAnswer(cmdHeader: String, objectHeader: String, state: Bool) -> String {
        let maker = XMLMaker(header: cmdHeader)
        var response: String
        if state == true {
            response = "done"
        } else {
            response = "fail"
        }
        
        let obj = XMLObject(header: objectHeader)
        return maker.toResponse(obj.toResponse(response))
    }

    func checkActionClient(parser: XMLParser, client: TCPClient) {
        
        switch parser.cmd! {
        case "nickname":
            client.nickname = parser.objects[0].object["name"]!
            //client.id = Int(parser.objects[0].object["id"]!)
            
            print("nickname command, nickaname : \(client.nickname) and id : \(client.id) fd: \(client.fd!)")
            print("answer:\n\(doAnswer("nickname", objectHeader: parser.objects[0].header!, state: true))")
            client.send(str: doAnswer("nickname", objectHeader: parser.objects[0].header!, state: true))
            break
        case "list":
            sendAllTable(client)
            break
        case "create":
            createNewTable(client, objectTable: parser.objects[0])
            break
        case "join":
            joinTable(client, idTable: parser.objects[0].object["id"]!)
            break
        case "info":
            giveInfoPlayer(client)
            break
        default:
            break
        }
    }
    
    func getIdNewTable() -> Int {
        return nbTableCreated + 1
    }

    func giveInfoPlayer(client: TCPClient) {
        print("request info asked!")
        let maker: XMLMaker = XMLMaker(header: "info")
        let obj: XMLObject = XMLObject(elems: ["id":"\(client.fd!)"], header: "player")
        
        maker.addXML(obj)
        print("response: \n\(maker.toString())")
        client.send(str: maker.toString())
    }
    
    func createNewTable(client: TCPClient, objectTable: XMLObject) {
        print("commande create received")
        let maker = XMLMaker(header: "create")
        let obj = objectTable

        obj.object["id"] = "\(getIdNewTable())"
        obj.object["idCreator"] = "\(client.fd!)"
        print(obj.object)
        
        let table: GameTable = GameTable(obj: obj)
        
        tables.append(table)
        nbTableCreated += 1
        maker.addXML(obj)

        print("response create:\n\(maker.toString())")
        client.send(str: maker.toString())
        print("response create sent")
        table.startThread()

    
    }
    
    
    func joinTable(client: TCPClient, idTable: String) {
        
        let id: Int = Int(idTable)!
        
        for table in tables {

            if table.id! == id {
                
                table.addNewPlayer(client)
                
                let maker: XMLMaker = XMLMaker(header: "join")
                let obj: XMLObject = XMLObject(header: "table")
                
                let (dic, tab) = table.getObjectToDic()
                obj.object = dic
                obj.objects = tab
                
                maker.addXML(obj)
                
                print("reponse to join request:\n\(maker.toString())")
                client.send(str: maker.toString())
                //set response join
                //table.startThread()
                break
            }
        }
    }
    
    func sendAllTable(client: TCPClient) {
        
        let maker: XMLMaker = XMLMaker(header: "list")
        
        for table in tables {
            let obj: XMLObject = XMLObject(elems: table.getDicObject(), header: "table")
            maker.addXML(obj)
        }
        
        print("response to list request:\n\(maker.toString())")
        client.send(str: maker.toString())
    }
    
}
