//
//  Response.swift
//  PokerGameServer
//
//  Created by Antoine roy on 20/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class Response: NSObject {

    var header: String?
    var response: String?
    
    init(obj: XMLObject) {
        super.init()
        
        self.header = obj.header
        self.response = obj.object["response"]
    }
    
    init(response: String, header: String) {
        self.header = header
        self.response = response
    }
    
    
    
}
