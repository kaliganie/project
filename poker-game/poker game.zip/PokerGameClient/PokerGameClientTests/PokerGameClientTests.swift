//
//  PokerGameClientTests.swift
//  PokerGameClientTests
//
//  Created by Antoine roy on 21/08/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import XCTest
@testable import PokerGameClient

class PokerGameClientTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testXMLMaker() {
        let maker: XMLMaker = XMLMaker(header: "test1")
        let maker2: XMLMaker = XMLMaker(header: "test2")
        
        XCTAssertNotEqual(maker.header!, maker2.header!)
        
        maker2.header = maker.header
        let obj: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "player")
        XCTAssertEqual(maker.toString(), maker2.toString(), "content equal")
        maker.addXML(obj)
        
        XCTAssertNotEqual(maker.toString(), maker2.toString())
        maker2.addXML(obj)
        XCTAssertEqual(maker.toString(), maker2.toString())
        
    }
    
    func testParserXMLResponse() {
        let maker: XMLMaker = XMLMaker(header: "test1")
        let obj: XMLObject = XMLObject(header: "player")
        
        let parser: XMLParser = XMLParser(xml: maker.toResponse(obj.toResponse("done")))
        XCTAssertEqual(parser.objects[0].response, "<done>")
        
    }
    
    func testParserXMLObject() {
        let maker: XMLMaker = XMLMaker(header: "test1")
        let obj: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "player")
        let obj2: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "player")
        
        maker.addXML(obj)
        maker.addXML(obj2)
        let parser: XMLParser = XMLParser(xml: maker.toString())
        XCTAssertEqual(parser.cmd!, "test1")
        for p in parser.objects {
            XCTAssertEqual(p.header!, "player")
        }
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
