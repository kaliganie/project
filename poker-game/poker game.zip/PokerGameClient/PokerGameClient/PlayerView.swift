//
//  PlayerView.swift
//  PokerGameClient
//
//  Created by Antoine roy on 14/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class PlayerView: UIView {

    /*@IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    
    @IBOutlet weak var card1: UIImageView!
    @IBOutlet weak var card2: UIImageView!
 
    @IBOutlet weak var boutonCaca: UIButton!
    */
    var nameLabel: UILabel?
    var moneyLabel: UILabel?
    var card1: UIImageView?
    var card2: UIImageView?
    var boutonCaca: UIButton = UIButton()
    
    var id: Int?
    var btn : ViewBtnSit = ViewBtnSit()
    
    
    
    class func instanceFromNib() -> PlayerView {
        
        //set array messages.
        return UINib(nibName: "PlayerView", bundle: nil).instantiateWithOwner(nil, options: nil)[0] as! PlayerView
        
    }

    override init(frame: CGRect) {
        print("override init frame")
        super.init(frame: frame)
        self.frame = frame
    }
    
    func createContent() {
        let ratio: CGFloat = 1.48
        let ratioLabel: CGFloat = 100 / 13
        
        print("frame: \(self.frame)")
        nameLabel = UILabel(frame: CGRectMake(0, 0, self.frame.width, CGFloat(self.frame.width / ratioLabel)))
        moneyLabel = UILabel(frame: CGRectMake(0, self.frame.height - CGFloat(self.frame.width / ratioLabel), self.frame.width, CGFloat(self.frame.width / ratioLabel)))
        card1 = UIImageView(frame: CGRectMake(0, nameLabel!.frame.height,
            self.frame.width / 2, (self.frame.width / 2) * ratio))
        card2 = UIImageView(frame: CGRectMake(card1!.frame.width, nameLabel!.frame.height,
            self.frame.width / 2, (self.frame.width / 2) * ratio))
        
        boutonCaca = UIButton(frame: CGRectMake(0, 0, self.frame.width, self.frame.height))
        
        nameLabel!.font = UIFont(name: nameLabel!.font.fontName, size: 7)
        nameLabel!.textAlignment = .Center
        moneyLabel!.font = UIFont(name: moneyLabel!.font.fontName, size: 7)

        moneyLabel!.textAlignment = .Center
        
        card1!.layer.cornerRadius = 3
        card1!.layer.borderWidth = 0.4
        
        card2!.layer.cornerRadius = 3
        card2!.layer.borderWidth = 0.4
        
        self.addSubview(nameLabel!)
        self.addSubview(moneyLabel!)
        self.addSubview(card1!)
        self.addSubview(card2!)
        self.addSubview(boutonCaca)
        
        self.card1!.hidden = true
        self.card2!.hidden = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func updateContent(player: Player, show: Bool) {
    
        self.layer.borderWidth = 1
        print("show ? \(show)")
        
        self.nameLabel!.text = player.nickname!
        self.moneyLabel!.text = "\(player.money!)$"
        
        self.card1!.hidden = false
        self.card2!.hidden = false

        if show == true {
            if player.cards.count == 2 {
                
                card1?.image = player.cards[0].img
                card2?.image = player.cards[1].img
            }
        } else {
            //change the picture with back of the card
            if player.cards.count == 2 {
                self.card1!.image = UIImage(named: "backCard")
                self.card2!.image = UIImage(named: "backCard")
            }
        }

    }
    
    func setSelectable() {
        
        btn.frame = CGRectMake(0, 0, self.frame.width, self.frame.height)
        
        btn.createContent()
        btn.btnSit.addTarget(self, action: #selector(PlayerView.hideView), forControlEvents: UIControlEvents.TouchUpInside)
        
        self.addSubview(btn)
    }
    
    func hideView() {
        print("-----------------yolo here !!!!!---------------")
        self.btn.removeFromSuperview()
    }
    
    
}
