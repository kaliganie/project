//
//  ListTableViewController.swift
//  PokerGameClient
//
//  Created by Antoine roy on 23/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class ListTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var listTable: [GamingTable]?
    var selfClient: Client?
    
    @IBOutlet weak var listTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let value = UIInterfaceOrientation.Portrait.rawValue
        UIDevice.currentDevice().setValue(value, forKey: "orientation")
        
        listTableView.delegate = self
        listTableView.dataSource = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (listTable?.count)!
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCellWithIdentifier("ListTableIdentifier") as! ListTableCell
        
        let table = listTable![indexPath.row]
        
        
        let slideGestureRecognizer: EECellSwipeGestureRecognizer = EECellSwipeGestureRecognizer()
        let leftPullAction: EECellSwipeAction = EECellSwipeAction(fraction: -0.25)
        leftPullAction.icon = UIImage(named: "btnJoinTable")!
        leftPullAction.activeBackgroundColor = UIColor.greenColor()
        leftPullAction.behavior = .Push
        leftPullAction.didTrigger = { (tableView, indexPath) in
            
            let (join, parser) = (self.selfClient?.joinTable(table))!
            
            if join {
                let GameStoryboard = UIStoryboard(name: "Game", bundle: nil)
                let GameVc = GameStoryboard.instantiateViewControllerWithIdentifier("GameViewControllerId") as? GameViewController
                
                table.initUserTable(self.selfClient!)
                table.updatePlayers(parser.objects[0].objects)
                table.updateDataTable(parser.objects[0].object)
                GameVc?.table = table
                
                self.presentViewController(GameVc!, animated: true, completion: nil)
            }
       
        }
        
        slideGestureRecognizer.addActions([leftPullAction])
        cell.addGestureRecognizer(slideGestureRecognizer)
 
        
        cell.tableNameLabel.text = table.name
        cell.tablePlayersLabel.text = "\(table.players!) / \(table.maxPlayers!) players"
        let (s, b) = Blind.getValueBlind(table.type!)
        cell.tableBlindLabel.text = "\(s) : \(b)"
        
        return cell
    }
    
    
    override func shouldAutorotate() -> Bool {
        return false
    }
    
    
    
}
