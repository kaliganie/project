//
//  Client.swift
//  PokerGameClient
//
//  Created by Antoine roy on 19/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class Client: TCPClient {

    var nickname: String?
    var id: Int?
    
    func connectToServer(addr: String, port: Int) -> (Bool, String) {
        
        self.addr = addr
        self.port = port
        let (success, msg) = self.connect(timeout: 5)
        
        if !success {
            print(msg)
        }
        
        return (success, msg)
    }
    
    func gamingReading() -> XMLParser {
        let data = self.read(1024*10)
        if let d = data {
            if let str=String(bytes: d, encoding: NSUTF8StringEncoding){
                print("\(str)")
                
                
                let parser = XMLParser(xml: str)
                return parser
            }
        }
        print("fail reading")
        return XMLParser()
    }
    
    func readAnswer(response: Bool = true) -> XMLParser {
        let data = self.read(1024*10)
        if let d = data {
            if let str=String(bytes: d, encoding: NSUTF8StringEncoding){
                print("\(str)")
                
                
                let parser = XMLParser(xml: str, response: response)
                return parser
            }
        }
        print("fail reading")
        return XMLParser()
    }
    
    func checkResponse(response: String) -> Bool {
        switch response {
        case "<done>":
            return true
        case "<fail>":
            return false
        default:
            return false
        }
    }
    
    func setNickname() {
        /*if nickname![nickname!.endIndex.predecessor()] == " " {
            nickname = String(nickname?.characters.dropLast())
        }*/
        let maker: XMLMaker = XMLMaker(header: "nickname")
        let object: XMLObject = XMLObject(elems: ["name" : nickname!, "id" : "\(fd!)"], header: "set")
        maker.addXML(object)
        print("sending request nickname:\n\(maker.toString())")
        self.send(str: maker.toString())
        
        let response = readAnswer()
        if response.cmd == "nickname" {
            if checkResponse(response.objects[0].response) == true {
                print("set nickname done")
            } else {
                print("set nickname fail")
            }
        }
    }
    
    func joinTable(table: GamingTable) -> (Bool, XMLParser) {
        let maker: XMLMaker = XMLMaker(header: "join")
        let obj: XMLObject = XMLObject(header: "table")
        
        let (dic, tab) = table.getObjectToDic()
        obj.object = dic
        obj.objects = tab
        
        maker.addXML(obj)
        self.send(str: maker.toString())
        
        let parser = self.readAnswer(false)
        
        if parser.cmd == "join" {
            return (true, parser)
        }
        return (false, parser)
    }
    
    func joinTable(elems: [String : String]) -> (Bool, GamingTable, XMLParser) {
        let maker: XMLMaker = XMLMaker(header: "join")
        let obj: XMLObject = XMLObject(elems: elems, header: "table")
        
        let table: GamingTable = GamingTable(obj: obj)
        
        maker.addXML(obj)
        self.send(str: maker.toString())
        
        let parser = self.readAnswer(false)
        
        if parser.cmd == "join" {
            return (true, table, parser)
        }
        return (false, table, parser)
    }
    
    func getListTable() -> ([GamingTable], String) {
        
        var tables: [GamingTable] = []
        let maker: XMLMaker = XMLMaker(header: "list")
        let obj: XMLObject = XMLObject(elems: ["nothing":"nothing"], header: "table")
        maker.addXML(obj)
        self.send(str: maker.toString())
        
        let response = readAnswer(false)
        if response.cmd == "list" {
            for obj in response.objects {
                tables.append(GamingTable(obj: obj))
            }
        } else {
            ([], "impossible to get the list of tables.")
        }
    
        if tables.isEmpty == true {
            return ([], "No table available.")
        }
        return (tables, "List of tables got successfully.")
        
    }
    
    func getInfoPlayer() {
        let maker: XMLMaker = XMLMaker(header: "info")
        let obj: XMLObject = XMLObject(elems: ["toto":"toto"], header: "player")
        
        maker.addXML(obj)
        self.send(str: maker.toString())
        
        let parser = readAnswer(false)
        if parser.cmd == "info" {
            
            self.id = Int(parser.objects[0].object["id"]!)
            
        }
    }
    
    func createTable(name: String, typeBlind: Int, nbPlayers: String) -> (Bool, String) {

        let obj: XMLObject = XMLObject(elems: ["name":name, "type":"\(typeBlind)", "maxPlayers":"\(nbPlayers)", "idCreator":"\(self.fd!)"], header: "table")
        let maker: XMLMaker = XMLMaker(header: "create")
        
        maker.addXML(obj)
        self.send(str: maker.toString())

        let response = readAnswer(false)
        if response.cmd == "create" {
            if response.objects[0].object["id"] != "" {
                print("create table done")
                let str = "\(response.objects[0].object["id"]!):\(response.objects[0].object["idCreator"]!)"
                return (true, str)
            } else {
                print("create table fail")
                return (false, "Impossible to create the table.")
            }
        }
        return (false, "Unknwon error...")
    }
    
}
