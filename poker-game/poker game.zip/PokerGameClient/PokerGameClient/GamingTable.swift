//
//  GamingTable.swift
//  PokerGameClient
//
//  Created by Antoine roy on 25/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class GamingTable: Table {

    var user: Player?
    var pot: Int?
    var listPlayers: [Player] = []
    
    
    func initUserTable(client: Client) {
        self.user = Player(client: client)
    }

    func updatePlayers(players: [XMLObject]) {
        listPlayers.removeAll()
        for obj in players {
            let p: Player = Player(obj: obj)
            listPlayers.append(p)
        }
    }
    
    func updateDataTable(dic: [String : String]) {
        
        if let id = dic["id"] {
            self.id = Int(id)
        }
        
        if let name = dic["name"] {
            self.name = name
        }
        
        if let type = dic["type"] {
            self.type = Int(type)
        }
        
        if let players = dic["players"] {
            self.players = Int(players)
        }
        
        if let maxPlayers = dic["maxPlayers"] {
            self.maxPlayers = Int(maxPlayers)
        }
        
        if let pot = dic["pot"] {
            self.pot = Int(pot)
        }
        
        
    }
    
    func getObjectToDic() -> ([String : String], [XMLObject]) {
        var dic = self.getDicObject()
        
        dic["pot"] = "\(self.pot)"
        var tabObj: [XMLObject] = []
        for p in listPlayers {
            tabObj.append(XMLObject(elems: p.getDicObject(), header: "player"))
        }
        
        return (dic, tabObj)
    }
    
}


