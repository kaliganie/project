//
//  Notification.swift
//  PokerGameClient
//
//  Created by Antoine roy on 29/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class Notification: UIView {

    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var information: UILabel!

    enum type: Int {
        case success = 0
        case error
        case info
    }
    
    var baseOrigin: CGPoint?
    
    
    class func instanceFromNib() -> Notification {
                
        return UINib(nibName: "Notification", bundle: nil).instantiateWithOwner(nil, options: nil)[0] as! Notification

    }
    
    func setBackground(t: Notification.type) {
        
        switch t {
        case .success:
            self.backgroundColor = UIColor.greenColor()
            self.icon.image = UIImage(named: "NotificationBackgroundSuccessIcon")
            break
        case .error:
            self.backgroundColor = UIColor.redColor()
            self.icon.image = UIImage(named: "NotificationBackgroundErrorIcon")
            break
        case .info:
            self.backgroundColor = UIColor.blueColor()
            self.icon.image = UIImage(named: "NotificationBackgroundWarningIcon")
            break
        }
        
    }
    
    
    func show(t: Notification.type, title: String, detail: String) {
        
        let boundDevice = UIScreen.mainScreen().bounds
        self.frame = CGRectMake(0, -self.frame.height, boundDevice.width, self.frame.height)
        baseOrigin = self.frame.origin
        setBackground(t)
        self.title.text = title
        self.information.text = detail
        self.hidden = false
        
        UIView.animateWithDuration(1, animations: {
            self.frame.origin = CGPointMake(0, 0)
            }, completion: { Void in
                
                NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: #selector(Notification.hide), userInfo: nil, repeats: false)
                
        })
        
        
        
    }
    
    func hide() {
        
        UIView.animateWithDuration(1, animations: {
            self.frame.origin = CGPointMake(0, self.baseOrigin!.y)
            }, completion: { Void in
                self.hidden = true
            })
        
    }

    
}
