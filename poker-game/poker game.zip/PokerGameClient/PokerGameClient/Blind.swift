//
//  Blind.swift
//  PokerGameClient
//
//  Created by Antoine roy on 08/08/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class Blind: NSObject {

    class func getValueBlind(type: Int) -> (Int, Int) {
        switch type {
        case 0:
            return (5, 10)
        case 1:
            return (10, 20)
        case 2:
            return (20, 40)
        default:
            return (0, 0)
        }
    }
    
}
