//
//  ActionsView.swift
//  PokerGameClient
//
//  Created by Antoine roy on 04/08/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

@IBDesignable class ActionsView: UIView {

    @IBOutlet weak var tableNameLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    
    @IBOutlet weak var startGameBtn: UIButton!
    @IBOutlet weak var LeaveTableBtn: UIButton!
    
    @IBOutlet weak var checkFoldBtn: UIButton!
    @IBOutlet weak var callBtn: UIButton!
    @IBOutlet weak var raiseBtn: UIButton!
    
    
    @IBOutlet weak var slider: UISlider!
    var turnView: NextTurnView!
    
    // Our custom view from the XIB file
    var view: UIView!
    var pot: Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        xibSetup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        xibSetup()
    }
    
    func xibSetup() {
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [UIViewAutoresizing.FlexibleWidth, UIViewAutoresizing.FlexibleHeight]
        addSubview(view)
    }
    
    func loadViewFromNib() -> UIView {
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            let bundle = NSBundle(forClass: self.dynamicType)
            let nib = UINib(nibName: "ActionsViewIpad", bundle: bundle)
            let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
            
            return view
        } else {
            let bundle = NSBundle(forClass: self.dynamicType)
            let nib = UINib(nibName: "ActionsView", bundle: bundle)
            let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
            
            return view
        }

    }
    
    func setContentTurnView() {
        self.turnView = NextTurnView(frame: self.startGameBtn.frame)
        /*self.turnView.clock = DDHTimerControl(type: .Solid)
        self.turnView.clock.translatesAutoresizingMaskIntoConstraints = false
        self.turnView.clock.color = UIColor.orangeColor()
        self.turnView.clock.highlightColor = UIColor.redColor()
        self.turnView.clock.minutesOrSeconds = 15
        self.turnView.clock.titleLabel.text = "sec"
        self.turnView.clock.userInteractionEnabled = false
        
        self.turnView.clock.maxValue = 15
        self.turnView.clock.ringWidth = 10
        
        self.turnView.turnLabel.text = "yolo batard"
        self.view.addSubview(self.turnView)*/
    }

    @IBAction func sliderValueChange(sender: UISlider) {
        
        let value = Int(sender.value)
        
        moneyLabel.text = "\(value)"
        raiseBtn.setTitle("Raise to \(value)", forState: UIControlState.Normal)
    }
    
    @IBAction func setMinValue(sender: AnyObject) {
        slider.setValue(slider.minimumValue, animated: true)
        
        moneyLabel.text = "\(Int(slider.value))"
        raiseBtn.setTitle("Raise to \(Int(slider.value))", forState: UIControlState.Normal)
    }
    
    @IBAction func setMaxValue(sender: AnyObject) {
        slider.setValue(slider.maximumValue, animated: true)
        
        moneyLabel.text = "\(Int(slider.value))"
        raiseBtn.setTitle("Raise to \(Int(slider.value))", forState: UIControlState.Normal)
    }
    
    @IBAction func halfPot(sender: AnyObject) {
        slider.setValue(Float(pot / 2), animated: true)
        
        moneyLabel.text = "\(Int(slider.value))"
        raiseBtn.setTitle("Raise to \(Int(slider.value))", forState: UIControlState.Normal)
    }
    
    @IBAction func setPotValue(sender: AnyObject) {
        slider.setValue(Float(pot), animated: true)
        
        moneyLabel.text = "\(Int(slider.value))"
        raiseBtn.setTitle("Raise to \(Int(slider.value))", forState: UIControlState.Normal)
    }
    
}
