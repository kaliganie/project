//
//  Table.swift
//  PokerGameClient
//
//  Created by Antoine roy on 23/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class Table: NSObject {

    var id: Int?
    var name: String?
    var type: Int?
    var players: Int?
    var maxPlayers: Int?
    var idCreator: Int?
    var smallBlind: Int?
    var bigBlind: Int?
    var maxBet: Int?
    var animBet: Bool = false
    
    override init() {
        id = 0
        name = "No name"
        type = 0
        players = 0
        maxPlayers = 0
        idCreator = 0
    }
    
    init(obj: XMLObject) {
        super.init()
        
        print("init call from GamingTable")
        
        id = 0
        name = ""
        type = -1
        players = 0
        maxPlayers = 0
        idCreator = 0
        
        
        if let id = obj.object["id"] {
            self.id = Int(id)
        } else {
            print("id empty")
        }
        
        if let name = obj.object["name"] {
            self.name = name
        } else {
            print("name empty")
        }
        
        if let type = obj.object["type"] {
            self.type = Int(type)
        } else {
            print("type empty")
        }
        
        if let players = obj.object["players"] {
            self.players = Int(players)
        } else {
            print("players empty")
        }
        
        if let maxPlayers = obj.object["maxPlayers"] {
            self.maxPlayers = Int(maxPlayers)
        } else {
            print("maxPlayers empty")
        }
        
        if let idCreator = obj.object["idCreator"] {
            self.idCreator = Int(idCreator)
        }
        
        if let sb = obj.object["sb"] {
            self.smallBlind = Int(sb)
        }

        if let bb = obj.object["bb"] {
            self.bigBlind = Int(bb)
        }
        
        if let maxBet = obj.object["maxBet"] {
            self.maxBet = Int(maxBet)
        }
        
        if let animBet = obj.object["animBet"] {
            if animBet == "1" {
                self.animBet = true
            } else {
                self.animBet = false
            }
        }
    }
    
    func getDicObject() -> [String: String] {
        var dic: [String: String] = [:]
    
        dic["id"] = "\(self.id!)"
        dic["name"] = "\(self.name!)"
        dic["type"] = "\(self.type!)"
        dic["players"] = "\(self.players!)"
        dic["maxPlayers"] = "\(self.maxPlayers!)"
        dic["idCreator"] = "\(self.idCreator!)"
        
        let (s, b) = Blind.getValueBlind(self.type!)
        self.bigBlind = b
        self.smallBlind = s
        
        dic["sb"] = "\(self.smallBlind!)"
        dic["bb"] = "\(self.bigBlind!)"
        
        if maxBet != nil {
            dic["maxBet"] = "\(self.maxBet!)"
        }
        
        dic["animBet"] = "0"
        if animBet == true {
            dic["animBet"] = "1"
        }
        
        return dic
    }
    
    
    
}
