//
//  GameViewController.swift
//  PokerGameClient
//
//  Created by Antoine roy on 14/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {

    var table: GamingTable?
    
    var tableImage: UIImageView?
    var labelPot: UILabel?
    var tabBtnPlayer: [PlayerView] = []
    var tabMoneyPlayer: [UILabel] = []
    var tabImgDealer: [UIImageView] = []
    var centralCards: [UIImageView] = []
    var actionsView: ActionsView?
    
    var theTable: XMLObject?
    var threadClient: NSThread?
    var letRead: Bool = true
    let clock: DDHTimerControl = DDHTimerControl(type: .Solid)
    var timer = NSTimer()
    var played: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            UIDevice.currentDevice().setValue(UIInterfaceOrientation.Portrait.rawValue, forKey: "orientation")
        } else {
            UIDevice.currentDevice().setValue(UIInterfaceOrientation.LandscapeLeft.rawValue, forKey: "orientation")
        }
 
        self.view.frame = CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, UIScreen.mainScreen().bounds.height)
        
        print("size device: \(UIScreen.mainScreen().bounds.size)")

        var smallSize = UIScreen.mainScreen().bounds.size.width
        var bigSize = UIScreen.mainScreen().bounds.size.height
        if smallSize > UIScreen.mainScreen().bounds.size.height {
            smallSize = UIScreen.mainScreen().bounds.size.height
            bigSize = UIScreen.mainScreen().bounds.size.width
        }
        
        self.tableImage = UIImageView(frame: CGRectMake(0, 0, smallSize, smallSize))

        self.tableImage!.image = UIImage(named: "poker_table")
        
        self.view.backgroundColor = UIColor.greenColor()
        self.view.addSubview(self.tableImage!)
        
        setBtnPlayer((table?.maxPlayers)!)
        
        if theTable != nil {
            //updateMoneyLabel()
        }
        
        self.setActionsView(smallSize, bigSize: bigSize)
        //notification.frame.origin = CGPointMake(0, -notification.frame.height)
        //self.view.addSubview(self.notification)
        
        

    }
    
    override func viewDidAppear(animated: Bool) {
        if theTable != nil && theTable?.object["running"] == "1" {
            setClock()
        }
        
        
        if theTable != nil {
            doAutomaticBbSb()
        }
        threadClient = NSThread.init(target: self, selector: #selector(GameViewController.threadClientFct), object: nil)
        //let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)

        //self.performSelectorOnMainThread(#selector(GameViewController.self.threadClientFct), withObject: nil, waitUntilDone: false)
        threadClient!.start()
    }
    
    func doAutomaticBbSb() {
        var dealed = false
        
        if theTable?.object["dealed"] == "1" {
            dealed = true
        }
        
        for p in theTable!.objects {
            print("header: \(p.header)")
            if p.header! == "player" {

                let player: Player = Player(obj: p)
                
                print("------------->checking after update: dealed \(dealed), user.sit \(self.table?.user?.sit!) == player.sit \(player.sit!), betting turn \(player.bettingTurn)")
                
                print("verif for DISABLE: user.sit == \(self.table?.user?.sit!) -> p.sit == \(player.sit!); betting turn? \(player.bettingTurn)")
                if self.table?.user?.sit! == player.sit! && player.bettingTurn == false {
                    print("verif ok !!!")
                    disableAllAction()
                }
                
                if dealed == true && (player.moneyBet == nil || player.moneyBet! == 0) && self.table?.user?.sit! == player.sit! && player.bettingTurn == true {
                    print("checking done is bb \(player.bigBlind) or sb \(player.smallBlind)")
                    if player.bigBlind == true {
                        manualCallRequest(Int(theTable!.object["bb"]!)!)
                    } else if player.smallBlind == true {
                        manualCallRequest(Int(theTable!.object["sb"]!)!)
                    }
                }

            }
            
        }
        updateMoneyLabel()
    }
    
    func updateMoneyLabel() {
        for p in theTable!.objects {
            if p.header! == "player" {
                let player: Player = Player(obj: p)
                
                if player.moneyBet != nil && player.moneyBet! > 0 {
                    tabMoneyPlayer[player.sit!].text = "\(player.moneyBet!)"
                }
            }
        }
        
        if theTable?.object["animBet"] == "1" {
            animAllMoney()
        }
    }
    
    func setActionsView(smallSize: CGFloat, bigSize: CGFloat) {
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            actionsView = ActionsView(frame: CGRectMake(0, (tableImage?.frame.height)!, smallSize, bigSize - smallSize))
        } else {
            actionsView = ActionsView(frame: CGRectMake((tableImage?.frame.width)!, 0, bigSize - smallSize, smallSize))
        }
        actionsView?.LeaveTableBtn.addTarget(self, action: #selector(GameViewController.leaveTable), forControlEvents: .TouchUpInside)
        actionsView?.startGameBtn.addTarget(self, action: #selector(GameViewController.startGame), forControlEvents: .TouchUpInside)
        
        print("check for btn start: \((self.table?.idCreator!)!) == \(self.table?.user?.id!)")
        if (self.table?.idCreator!)! != self.table?.user?.id! {
            print("comparaison ids done !!")
            actionsView?.startGameBtn.hidden = true
        }

        if theTable != nil {
            let sb: Int = Int((theTable?.object["sb"])!)!
            
            var maxbet: Int = 0
            if let mb = theTable?.object["maxBet"] {
                maxbet = Int(mb)!
            }
        
            let value = sb + maxbet
            actionsView!.moneyLabel.text = "\(value)"
            actionsView!.pot = Int((theTable?.object["pot"])!)!
            actionsView?.slider.minimumValue = Float(sb)
            
            if theTable?.object["started"] == "1" {
                actionsView?.startGameBtn.hidden = true
            }
            
            var max = 0
            for p in (theTable?.objects)! {
                if p.header! == "player" {
                    let sit: Int = Int(p.object["sit"]!)!
                    if sit == self.table?.user?.sit! {
                        max = Int(p.object["money"]!)!
                        if let valMaxBet = p.object["moneyBet"] {
                            if maxbet == Int(valMaxBet) {
                                actionsView?.callBtn.hidden = true
                                actionsView?.checkFoldBtn.setTitle("Check", forState: .Normal)
                            }
                        }
                        
                        break
                    }
                }
            }
            actionsView?.raiseBtn.setTitle("Raise to \(Int((actionsView?.slider.maximumValue)!))", forState: .Normal)
            actionsView?.slider.maximumValue = Float(max)
        }
  
        actionsView!.layer.borderWidth = 1
        actionsView!.tableNameLabel.text = "\(actionsView!.tableNameLabel.text!) \((self.table?.name!)!)"
        
        actionsView?.callBtn.addTarget(self, action: #selector(GameViewController.requestCall), forControlEvents: .TouchUpInside)
        actionsView?.raiseBtn.addTarget(self, action: #selector(GameViewController.requestRaise), forControlEvents: .TouchUpInside)
        actionsView?.checkFoldBtn.addTarget(self, action: #selector(GameViewController.requestCheckFold), forControlEvents: .TouchUpInside)
 
        //actionsView?.setContentTurnView()
        self.view.addSubview(self.actionsView!)
    }

    func setClock() {
        
        /*clock.translatesAutoresizingMaskIntoConstraints = false
        clock.color = UIColor.orangeColor()
        clock.highlightColor = UIColor.redColor()
        clock.minutesOrSeconds = 15
        clock.titleLabel.text = "sec"
        clock.userInteractionEnabled = false
        clock.frame = CGRectMake((actionsView?.startGameBtn.frame.origin.x)!, (actionsView?.startGameBtn.frame.origin.y)!, (actionsView?.startGameBtn.frame.height)!, (actionsView?.startGameBtn.frame.height)!)
        clock.maxValue = 15
        clock.ringWidth = 10
        actionsView?.addSubview(clock)*/
        
        /*let label: UILabel = UILabel(frame: CGRectMake(clock.frame.origin.x + clock.frame.width + 8, (clock.frame.origin.y) + ((actionsView?.startGameBtn.frame.height)! / 2) - 10, 120, 20))*/
        var frame: CGRect?
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            frame = CGRectMake((actionsView?.startGameBtn.frame.origin.x)!, (actionsView?.startGameBtn.frame.origin.y)!, (actionsView?.startGameBtn.frame.width)!, (actionsView?.startGameBtn.frame.height)!)
        } else {
            frame = CGRectMake((actionsView?.startGameBtn.frame.origin.x)!, (actionsView?.startGameBtn.frame.origin.y)!, (actionsView?.startGameBtn.frame.width)!, (actionsView?.startGameBtn.frame.height)!)
        }
        let label: UILabel = UILabel(frame: frame!)
        for obj in (theTable?.objects)! {
            if obj.header! == "player" && obj.object["bettingTurn"] == "1" {
                label.text = "\(obj.object["name"]!)'s turn"
                label.font = UIFont(name: label.font.fontName, size: 20)
            }
        }
        
        actionsView?.addSubview(label)
        
        print("frame btn: \(actionsView?.startGameBtn.frame)\n frame clock: \(clock.frame)")
    }
    
    func disableAllAction() {
        actionsView?.checkFoldBtn.enabled = false
        actionsView?.callBtn.enabled = false
        actionsView?.raiseBtn.enabled = false
        timer.invalidate()
    }
    
    func update() {
        if played == false {
            if self.clock.minutesOrSeconds > 0 {
                self.clock.minutesOrSeconds -= 1
                print("timer still working for tag: \(self.view.tag)")
            } else {
                print("fin du chrono")
                timer.invalidate()
                for obj in (theTable?.objects)! {
                    if obj.header == "player" && table?.user?.sit! == Int(obj.object["sit"]!) && obj.object["bettingTurn"] == "1" {
                        requestCheckFold()
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func animAllMoney() {
        print("I'm here, it's good")
        for l in tabMoneyPlayer {
            
            let frame = l.frame
            UIView.animateWithDuration(1, animations: {
                
                l.frame = (self.labelPot?.frame)!
                
                }, completion: { Void in
                    l.frame = frame
                    l.text = "0"
            })
            
        }
    }
    
    func threadClientFct() {
        repeat {
            timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(GameViewController.update), userInfo: nil, repeats: true)
            let parser: XMLParser = (table?.user?.gamingReading())!
            switch parser.cmd! {
            case "update":
                print("commande update")
                theTable = parser.objects[0]
                timer.invalidate()
                tabBtnPlayer[0].boutonCaca.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
            case "start":
                if parser.objects[0].response == "<fail>" {
                    //self.notification.show(Notification.type.error, title: "Error", detail: "Waiting for more Players.")
                }
            case "leave":
                if parser.objects[0].response == "<fail>" {
                    //self.notification.show(Notification.type.error, title: "Error", detail: "Impossible to leave the table.")
                } else {
                    let vc = topMostController()
                    
                    self.table?.user?.close()
                    self.threadClient?.cancel()
                    letRead = false
                    let MainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let mainVc = MainStoryboard.instantiateViewControllerWithIdentifier("ConnectionIdentifier") as? ConnectionViewController
                    timer.invalidate()
                    mainVc?.view.tag = self.view.tag + 1
                    vc.presentViewController(mainVc!, animated: true, completion: nil)
                    
                    //self.dismissViewControllerAnimated(true, completion: nil)
                    //self.notification.show(Notification.type.error, title: "Success", detail: "You are leaving the table.")
                }
            case "sit":
                if parser.objects[0].response == "<done>" {
                    print("sitting done")
                    
                    for sit in tabBtnPlayer {
                        sit.btn.hidden = true
                        
                    }
                    
                } else {
                    print("sitting failed")     
                }
            case "central":
                let central : XMLObject = parser.objects[0]
                var i = 0
                for card in centralCards {
                    if (central.object.count) - 1 >= i {
                        print("central card \(i) : \(central.object["card\(i)"])")
                        card.image = UIImage(named: (central.object["card\(i)"])!)
                    } else {
                        card.image = UIImage(named: "backCard")
                    }
                    i += 1
                }
            case "call":
                let p: XMLObject = parser.objects[0]
                print("update Call")
                tabMoneyPlayer[Int(p.object["sit"]!)!].text = "\(p.object["moneyBet"]!)"
            case "fold":
                break
            case "check":
                break
            case "raise":
                break
            case "endBetting":
                print("receive endBetting command")
                //self.performSelectorOnMainThread(#selector(GameViewController.self.animAllMoney), withObject: nil, waitUntilDone: true)
                dispatch_async(dispatch_get_main_queue()) {
                    self.animAllMoney()
                }
                
            default: break
                //letRead = false
            }
            
            timer.invalidate()
            if letRead == false {
                print("letRead == false")
                let vc = topMostController()
                
                let MainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let mainVc = MainStoryboard.instantiateViewControllerWithIdentifier("ConnectionIdentifier") as? ConnectionViewController
                vc.presentViewController(mainVc!, animated: true, completion: nil)

            }
        } while letRead == true
    }
    
    func topMostController() -> UIViewController {
        var topController: UIViewController = UIApplication.sharedApplication().keyWindow!.rootViewController!
        while (topController.presentedViewController != nil) {
            topController = topController.presentedViewController!
        }
        return topController
    }
    
    func updateTable() {
        
        print("--------------UPDATEEEEEEEE-------------")
        
        print("\nthere are \(theTable!.objects.count) players in the tab\n")
        print("content: \(theTable!.object)")
        
        
        dispatch_async(dispatch_get_main_queue(), {
            self.view.translatesAutoresizingMaskIntoConstraints = true
            let GameStoryboard = UIStoryboard(name: "Game", bundle: nil)
            let GameVc = GameStoryboard.instantiateViewControllerWithIdentifier("GameViewControllerId") as? GameViewController
            GameVc!.table = self.table
            GameVc!.theTable = self.theTable
            GameVc?.view.frame = self.view.frame
            GameVc?.view.translatesAutoresizingMaskIntoConstraints = true
            self.timer.invalidate()
            GameVc?.view.tag = self.view.tag + 1
            self.threadClient?.cancel()
            //self.letRead = false
            self.topMostController().presentViewController(GameVc!, animated: false, completion: nil)
        })
        
    }
    
    func setCentralCards() {
        let ratio: CGFloat = 1.48
        let space: CGFloat = 10
        let sizeCard: CGFloat = tabBtnPlayer[0].frame.width / 2
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) - (2 * space) - (CGFloat(2.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) - (1 * space) - (CGFloat(1.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) - (0 * space) - (CGFloat(0.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) + (1 * space) + (CGFloat(0.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        centralCards.append(UIImageView(frame: CGRectMake(((tableImage?.frame.width)! / 2) + (2 * space) + (CGFloat(1.5) * sizeCard), ((tableImage?.frame.height)! / 2) - ((sizeCard * ratio) / 2), sizeCard, sizeCard * ratio)))
        
        
        var i = 0
        var central: XMLObject?
        
        if theTable != nil {
            for obj in (theTable?.objects)! {
                if obj.header! == "centralCards" {
                    central = obj
                    break
                }
            }
        }
        if central != nil {
            print("nb central cards : \(central?.object.count)")
        }
        for card in centralCards {
            if theTable != nil && central != nil && (central?.object.count)! - 1 >= i {
                print("central card \(i) : \(central?.object["card\(i)"])")
                card.image = UIImage(named: (central?.object["card\(i)"])!)
            } else {
                card.image = UIImage(named: "backCard")
            }
            card.layer.borderWidth = 0.4
            card.layer.cornerRadius = 3
            self.view.addSubview(card)
            i += 1
        }
    }
    
    func setPotMoney() {
        labelPot = UILabel(frame: CGRectMake((tableImage!.frame.width / 2) - centralCards[1].frame.width, centralCards[2].frame.origin.y + centralCards[0].frame.height + 10, centralCards[1].frame.width * 2, 20))
        
        if theTable != nil && theTable?.object["pot"] != nil {
            let pot: Int = Int((theTable?.object["pot"])!)!
            labelPot?.text = "\(pot)$"
        }
        
        labelPot?.textColor = UIColor.whiteColor()
        labelPot?.textAlignment = .Center
        self.view.addSubview(labelPot!)
    }
    
    func setBtnPlayer(nbPlayers: Int) {
        
        var i = 0
        repeat {
            let (points, sizes) = getFrameBtn(i)
            let (p, s) = getFrameDealer(i)
            let (lp, ls) = getFrameMoney(i)
            
            let btn: PlayerView = PlayerView(frame: CGRectMake(points.x, points.y, sizes.width, sizes.height))
            let img: UIImageView = UIImageView(frame: CGRectMake(p.x, p.y, s.width, s.height))
            let label: UILabel = UILabel(frame: CGRectMake(lp.x, lp.y, ls.width, ls.height))
            
            img.image = UIImage(named: "dealer")
            label.text = ""
            label.textAlignment = .Center
            label.textColor = UIColor.whiteColor()
            
            tabBtnPlayer.append(btn)
            tabImgDealer.append(img)
            tabMoneyPlayer.append(label)
            
            tabBtnPlayer[i].createContent()
            
            tabBtnPlayer[i].btn.btnSit.tag = i
            tabBtnPlayer[i].btn.btnSit.addTarget(self, action: #selector(GameViewController.notificationSelectedBtn(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            btn.boutonCaca.addTarget(self, action: #selector(GameViewController.updateTable), forControlEvents: .TouchUpInside)

            tabBtnPlayer[i].tag = i
            
            if theTable == nil {
                var isSelectable = true
                for p in (table?.listPlayers)! {
                    if p.sit != nil && p.sit == i {
                        isSelectable = false
                        tabBtnPlayer[i].updateContent(p, show: false)
                    }
                }
                
                if isSelectable == true {
                    
                    
                    tabBtnPlayer[i].setSelectable()
                }
            }
            
            tabMoneyPlayer[i].hidden = true
            tabImgDealer[i].hidden = true
            
            self.view.addSubview(tabBtnPlayer[i])
            self.view.addSubview(tabImgDealer[i])
            self.view.addSubview(tabMoneyPlayer[i])
            
            i += 1
        } while i < nbPlayers
        
        setCentralCards()
        setPotMoney()
        
        if theTable != nil {
            
            print("---------------THE TABLE IS NOT NIL----------------")
            
            var dealed = false
            
            if theTable?.object["dealed"] == "1" {
                dealed = true
            }
            
            for p in theTable!.objects {
                print("header: \(p.header)")
                if p.header! == "player" {
                    print("comparaison done")
                    let player: Player = Player(obj: p)
                    var show: Bool = false
                    print("player : \(player.getDicObject())")
                    print("check ids -> user.id == \((table?.user?.id!)!) and player.fd == \(player.id!)")
                    if (table?.user?.id!)! == player.id! {
                        print("---------prepare to show ")
                        show = true
                    }
                    print("time to update sit \(player.sit!)\nthere are \(tabBtnPlayer.count) sits")
                
                    if player.moneyBet != nil {
                        tabMoneyPlayer[player.sit!].text = "\(player.moneyBet!)"
                    }
                    
                    if theTable?.object["animBet"] == "1" {
                        animAllMoney()
                    }
                    
                    if player.isDealer == true {
                        tabImgDealer[player.sit!].hidden = false
                    }
                    
                    tabBtnPlayer[player.sit!].moneyLabel!.text = "\(player.money!)"
                    
                    if theTable?.object["started"] == "1" || player.bettingTurn == true {
                        actionsView?.startGameBtn.hidden = true
                    }
                    
                    if dealed == true && (player.moneyBet == nil || player.moneyBet! == 0) && self.table?.user?.sit! == player.sit! && player.bettingTurn == true {
                        print("checking done is bb \(player.bigBlind) or sb \(player.smallBlind)")
                        if player.bigBlind == true {
                            tabBtnPlayer[player.sit!].moneyLabel!.text = "\(player.money! - Int(theTable!.object["bb"]!)!)"
                        } else if player.smallBlind == true {
                            tabBtnPlayer[player.sit!].moneyLabel!.text = "\(player.money! - Int(theTable!.object["sb"]!)!)"
                        }
                    }
                    
                    tabMoneyPlayer[player.sit!].hidden = false
                    
                    tabBtnPlayer[player.sit!].updateContent(player, show: show)
                } else if p.header! == "centralCards" {
                    print("updating central cards")
                }

            }
            
            
        }
        
    }
    
    
    
    func notificationSelectedBtn(sender: UIButton) {
        
        // request sit
        let maker: XMLMaker = XMLMaker(header: "sit")
        let obj: XMLObject = XMLObject(elems: ["id":"\(table?.id)", "sit":"\(sender.tag)"], header: "table")
        
        table?.user?.sit = sender.tag
        maker.addXML(obj)
        table?.user?.send(str: maker.toString())
    }
    
    func leaveTable() {
        let maker: XMLMaker = XMLMaker(header: "leave")
        let obj: XMLObject = XMLObject(elems: ["id" : "\(self.table?.user?.fd!)"], header: "player")
        
        maker.addXML(obj)
        self.table?.user?.send(str: maker.toString())
        /*let parser = self.table?.user?.gamingReading()
        if parser?.cmd == "leave" {
            print("leave the table")
        }*/
    }
    
    func startGame() {
        print("start game request")
        let maker: XMLMaker = XMLMaker(header: "start")
        let obj: XMLObject = XMLObject(elems: ["id" : "\(self.table?.id!)"], header: "table")
        
        maker.addXML(obj)
        print("request: \n\(maker.toString())")
        self.table?.user?.send(str: maker.toString())
    }
    
    func requestCheckFold() {
        print("request \(actionsView?.checkFoldBtn.titleLabel?.text)")
        if actionsView?.checkFoldBtn.titleLabel?.text == "Fold" {
            print("fold request")
            let maker: XMLMaker = XMLMaker(header: "fold")
            let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)"], header: "player")
            maker.addXML(obj)

            table?.user?.send(str: maker.toString())
            disableAllAction()
        } else {
            requestCall()
        }
        
        timer.invalidate()
        
    }
    
    func requestCall() {
        if theTable != nil {
            print("request Call")
            let maker: XMLMaker = XMLMaker(header: "call")
            
            //var param: [String : String] = [:]
            var value = 0
            if let maxBet = theTable?.object["maxBet"] {
                value = Int(maxBet)!
            }

            
            if value == 0 {
                value = Int((theTable?.object["bb"])!)!
            }
            let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)", "moneyPut":"\(value)"], header: "player")
            
            maker.addXML(obj)
            self.table?.user?.send(str: maker.toString())
            disableAllAction()
            timer.invalidate()
            played = true
        }
    }
    
    func manualCallRequest(value: Int) {
        let maker: XMLMaker = XMLMaker(header: "call")
        
        
        let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)", "moneyPut":"\(value)"], header: "player")
        
        maker.addXML(obj)
        print("manual call request :\n\(maker.toString())")
        self.table?.user?.send(str: maker.toString())
        disableAllAction()
        timer.invalidate()
        played = true
    }
    
    func requestRaise() {
        print("request Raise")
        let maker: XMLMaker = XMLMaker(header: "raise")
        let obj: XMLObject = XMLObject(elems: ["sit":"\(table?.user?.sit!)", "moneyPut":(actionsView?.moneyLabel.text)!], header: "player")
        
        maker.addXML(obj)
        self.table?.user?.send(str: maker.toString())
        disableAllAction()
        timer.invalidate()
        played = true
    }
    
    
    
    func getFrameMoney(pos: Int) -> (CGPoint, CGSize) {
        
        let sizeTable: CGSize = self.tableImage!.frame.size
        let ratio: CGFloat = 7.5
        let frameBtn: CGSize = CGSizeMake(sizeTable.width / ratio, sizeTable.height / ratio)
        let sizeDiag = (3 / 4) * frameBtn.width
        let frameLabel: CGSize = CGSizeMake(60, 20)
        
        switch pos {
        case 0:
            return (CGPointMake(frameBtn.width + ratio, (sizeTable.width / 2) - (frameLabel.height / 2)), frameLabel)
        case 1:
            return (CGPointMake(sizeTable.width - frameBtn.width - ratio - frameLabel.width, (sizeTable.height / 2) - (frameLabel.height / 2)), frameLabel)
        case 2:
            return (CGPointMake((sizeTable.width / 2) - (frameLabel.width / 2), frameBtn.height + (ratio * 2)), frameLabel)
        case 3:
            return (CGPointMake((sizeTable.width / 2) - (frameLabel.width / 2), sizeTable.height - frameBtn.height - (ratio * 2) - frameLabel.height), frameLabel)
        case 4:
            return (CGPointMake(sizeDiag + frameBtn.width + ratio, sizeDiag + frameBtn.height + ratio + frameLabel.height), frameLabel)
        case 5:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag - frameLabel.width, sizeTable.height - frameBtn.height - sizeDiag - (ratio * 2) - (frameLabel.height * 2)), frameLabel)
        case 6:
            return (CGPointMake(sizeDiag + frameBtn.width + ratio, sizeTable.height - frameBtn.height - sizeDiag - ratio - (frameLabel.height * 2)), frameLabel)
        case 7:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag - frameLabel.width - ratio, sizeDiag + frameBtn.height + ratio + frameLabel.height), frameLabel)
        default:
            return (CGPointMake(0, 0), CGSizeMake(0, 0))
        }
    }
    
    func getFrameDealer(pos: Int) -> (CGPoint, CGSize) {
        
        let sizeTable: CGSize = self.tableImage!.frame.size
        let ratio: CGFloat = 7.5
        let frameBtn: CGSize = CGSizeMake(sizeTable.width / ratio, sizeTable.height / ratio)
        let sizeDiag = (3 / 4) * frameBtn.width
        let frameImg: CGSize = CGSizeMake(frameBtn.width / 5, frameBtn.height / 5)
        
        switch pos {
        case 0:
            return (CGPointMake(frameBtn.width + ratio, (sizeTable.width / 2) + (frameBtn.width / 2) - frameImg.height), frameImg)
        case 1:
            return (CGPointMake(sizeTable.width - frameBtn.width - ratio - frameImg.width, (sizeTable.height / 2) - (frameBtn.height / 2)), frameImg)
        case 2:
            return (CGPointMake((sizeTable.width / 2) - (frameBtn.width / 2), frameBtn.height + ratio), frameImg)
        case 3:
            return (CGPointMake((sizeTable.width / 2) + (frameBtn.width / 2) - frameImg.width, sizeTable.height - frameBtn.height - ratio - frameImg.height), frameImg)
        case 4:
            return (CGPointMake(sizeDiag + frameBtn.width - frameImg.width + ratio, sizeDiag + frameBtn.height + frameImg.height + ratio), frameImg)
        case 5:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag, sizeTable.height - frameBtn.height - sizeDiag - (ratio * 2) - (frameImg.height * 2)), frameImg)
        case 6:
            return (CGPointMake(sizeDiag + frameBtn.width + frameImg.width + ratio, sizeTable.height - frameBtn.height - sizeDiag - ratio), frameImg)
        case 7:
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag - (frameImg.width * 2) - ratio, sizeDiag + frameBtn.height - frameImg.height + ratio), frameImg)
        default:
            return (CGPointMake(0, 0), CGSizeMake(0, 0))
        }
    }
    
    func getFrameBtn(pos: Int) -> (CGPoint, CGSize) {
        
        let sizeTable: CGSize = self.tableImage!.frame.size
        let ratio: CGFloat = 7.5
        let frameBtn: CGSize = CGSizeMake(sizeTable.width / ratio, sizeTable.height / ratio)
        let sizeDiag = (3 / 4) * frameBtn.width
        
        switch pos{
        case 0: //left
            return (CGPointMake(0, (sizeTable.width / 2) - (frameBtn.width / 2)), frameBtn)
        case 1: // right
            return (CGPointMake(sizeTable.width - frameBtn.width, (sizeTable.height / 2) - (frameBtn.height / 2)), frameBtn)
        case 2: //top
            return (CGPointMake((sizeTable.width / 2) - (frameBtn.width / 2), 0), frameBtn)
        case 3: //bottom
            return (CGPointMake((sizeTable.width / 2) - (frameBtn.width / 2), sizeTable.height - frameBtn.height), frameBtn)
        case 4: //top-left
            return (CGPointMake(sizeDiag, sizeDiag), frameBtn)
        case 5: // bottom-right
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag, sizeTable.height - frameBtn.height - sizeDiag), frameBtn)
        case 6: //bottom-left
            return (CGPointMake(sizeDiag, sizeTable.height - frameBtn.height - sizeDiag), frameBtn)
        case 7: //top-right
            return (CGPointMake(sizeTable.width - frameBtn.width - sizeDiag, sizeDiag), frameBtn)
        default:
            return (CGPointMake(0, 0), CGSizeMake(0, 0))
        }
    }
    
    override func shouldAutorotate() -> Bool {
        return false
    }
    
}

