//
//  XMLMaker.swift
//  PokerGameClient
//
//  Created by Antoine roy on 18/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class XMLMaker: NSObject {

    var tabXML: [XMLObject] = []
    var header: String?
    
    
    init(header: String) {
        self.header = header
    }
    
    func getHeaderTop() -> String {
        return "<\(header!)>\n"
    }
    
    func getHeaderEnd() -> String {
        return "<\\\(header!)>"
    }
    
    
    
    func addXML(obj: XMLObject, pos: Int = -1) {
        if pos == -1 {
            tabXML.append(obj)
        } else {
            tabXML.insert(obj, atIndex: pos)
        }
    }
    
    func addMultipleXML(objs: [XMLObject]) {
        for obj in objs {
            tabXML.append(obj)
        }
    }
    
    func removeXML(pos: Int) {
        tabXML.removeAtIndex(pos)
    }
    
    
    func toString() -> String {
        var strXML: String
        
        strXML = getHeaderTop()
        for obj in tabXML {
            strXML += obj.toString()
        }
        strXML += getHeaderEnd()
        
        
        return strXML
    }
    
    func toResponse(obj: String) -> String{
        var strXML: String
        
        strXML = getHeaderTop()
        strXML += obj
        strXML += getHeaderEnd()
        
        return strXML
    }
    
}
