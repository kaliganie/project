//
//  blindTableViewCell.swift
//  PokerGameClient
//
//  Created by Antoine roy on 24/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class LabelTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        print("init the cell")
        super.awakeFromNib()
        // Initialization code
    }

}
