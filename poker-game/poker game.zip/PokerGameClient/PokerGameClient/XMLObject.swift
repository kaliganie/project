//
//  XMLObject.swift
//  PokerGameClient
//
//  Created by Antoine roy on 18/07/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import Foundation

class XMLObject: NSObject {

    var object: [String: String] = [:]
    var objects: [XMLObject] = []
    var header: String?
    var response: String = ""
    
    override init() {
        super.init()

        self.header = ""
    }
    
    init(elems: [String : String], header: String) {
        object = elems
        self.header = header
    }
    
    init(response: String, header: String) {
        super.init()
        
        self.response = response
        self.header = header
    }
    
    init(header: String) {
        self.header = header
    }
    
    func makeObject(elems: [String : String], header: String) {
        object = elems
        self.header = header
    }
    
    func writeHeaderTop() -> String {
        return "<\(header!)>\n"
    }
    
    func writeHeaderEnd() -> String {
        return "<\\\(header!)>\n"
    }
    
    func makeBalise(name: String) -> String {
        return "<\(name)>:\(object[name]!)\n"
    }
    
    
    
    
    
    func toString() -> String {
        let keys = object.keys
        var str: String = writeHeaderTop()
        
        for key in keys {
            str += makeBalise(key)
        }
        for obj in objects {
            str += obj.toString()
        }
        
        str += writeHeaderEnd()
        
        return str
    }
    
    func toResponse(response: String) -> String {
        
        var str: String = writeHeaderTop()
        
        str += "<\(response)>\n"
        
        str += writeHeaderEnd()
        
        return str
    }
    
}
