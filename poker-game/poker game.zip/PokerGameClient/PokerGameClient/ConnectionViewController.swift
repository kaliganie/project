//
//  ConnectionViewController.swift
//  PokerGameClient
//
//  Created by Antoine roy on 18/06/2016.
//  Copyright © 2016 Antoine roy. All rights reserved.
//

import UIKit

class ConnectionViewController: UIViewController, UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var ipTextField: UITextField!
    @IBOutlet weak var portTextField: UITextField!
    @IBOutlet weak var nicknameField: UITextField!
    
    var listTable: [GamingTable] = []
    
    let createView: PopUpView = PopUpView.instanceFromNib()
    let notification: Notification = Notification.instanceFromNib()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let value = UIInterfaceOrientation.Portrait.rawValue
        UIDevice.currentDevice().setValue(value, forKey: "orientation")
        
        ipTextField.delegate = self
        portTextField.delegate = self
        nicknameField.delegate = self
        
        
        ipTextField.text = "129.12.192.136"
        portTextField.text = "8080"
        nicknameField.text = "Antoine"
        
        
        self.addCreateViewToSuperview()
        self.addNotificationToSuperview()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ConnectionViewController.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ConnectionViewController.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    func addCreateViewToSuperview() {
        createView.frame = CGRectMake((UIScreen.mainScreen().bounds.width / 2) - 150, UIScreen.mainScreen().bounds.height, 300, 380)
        createView.tableView.delegate = self
        createView.tableView.dataSource = self
        createView.tableView.hidden = true
        createView.initContent()
        print("size view: \(createView.frame.size)")
        createView.layer.cornerRadius = 10
        self.view.addSubview(createView)
        self.view.bringSubviewToFront(createView)
        createView.hidden = true
        createView.tableNameField.delegate = self
        createView.createTableBtn.addTarget(self, action: #selector(ConnectionViewController.createTableAndJoin), forControlEvents: UIControlEvents.TouchUpInside)
        
        
        createView.tableNameField.text = "tortue ninja"
    }
    
    func addNotificationToSuperview() {
        notification.frame.origin = CGPointMake(0, -notification.frame.height)
        self.view.addSubview(notification)
        notification.hidden = true
    }

    func keyboardWillShow(notification: NSNotification) {
        
        if createView.hidden == true {
        
            if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue() {
                
                
                UIView.animateWithDuration(0.1, animations: {
                    self.view.frame = CGRectMake(0, -keyboardSize.height + 160, UIScreen.mainScreen().bounds.width, UIScreen.mainScreen().bounds.height)
                })
            }
        }
    }
    
    func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.1, animations: {
            self.view.frame = CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, UIScreen.mainScreen().bounds.height)
        })
    }
    
    func connectSrv() -> (Client, Bool, String) {
        let client: Client = Client()
        let (success, msg) = client.connectToServer(self.ipTextField.text!, port: Int(self.portTextField.text!)!)
        client.nickname = nicknameField.text!
        return (client, success, msg)
    }
    
    @IBAction func requestJoinTable(sender: AnyObject) {
        
        if checkContentFields() == true {
            
            let (client, success, msg) = connectSrv()
            
            if success {
                client.setNickname()
                client.getInfoPlayer()
                let (list, msg) = client.getListTable()
                print("is list empty? \(list.isEmpty) with msg: \(msg)")
                if list.isEmpty == false {
                    listTable = list
                    performSegueWithIdentifier("showListTable", sender: client)
                } else {
                    notification.show(Notification.type.error, title: "Error", detail: msg)
                }
            } else {
                notification.show(Notification.type.error, title: "Error", detail: msg)
            }
        } else {
            notification.show(Notification.type.error, title: "Error", detail: "All fields have to be filled")
        }
    }
    
    func createTableAndJoin() {
        if createView.tableNameField.text != "" && createView.blindLabel.text != "" && checkContentFields() == true {

            let (client, success, msg) = connectSrv()
            
            if success {
                client.setNickname()
                client.getInfoPlayer()
                let (created, id) = client.createTable(createView.tableNameField.text!, typeBlind: createView.getValueOfBlind(), nbPlayers: createView.playersField.text!)
                if created {
                    //notification.show(Notification.type.success, title: "Success", detail: "Table created... Please wait.")
                    var tab = id.characters.split{$0 == ":"}.map(String.init)
                    let params: [String : String] = ["id": tab[0], "name":createView.tableNameField.text!, "type":"\(createView.getValueOfBlind())", "players":"0", "maxPlayers":createView.playersField.text!, "idCreator":tab[1]]
                    
                    let (join, table, parser) = client.joinTable(params)
                    
                    if join {
                        let GameStoryboard = UIStoryboard(name: "Game", bundle: nil)
                        let GameVc = GameStoryboard.instantiateViewControllerWithIdentifier("GameViewControllerId") as? GameViewController
                        
                        table.initUserTable(client)
                        table.updatePlayers(parser.objects[0].objects)
                        table.updateDataTable(parser.objects[0].object)
                        GameVc?.table = table
                        
                        self.createView.removeFromSuperview()
                        self.notification.removeFromSuperview()

                        self.presentViewController(GameVc!, animated: true, completion: nil)
                    } else {
                        notification.show(.error, title: "Error", detail: "Impossible to join the table")
                    }
                    
                    
                    print(table)
                } else {
                    notification.show(Notification.type.error, title: "Error", detail: id)
                }
            } else {
                notification.show(Notification.type.error, title: "Error", detail: msg)
            }
        } else {
            notification.show(Notification.type.error, title: "Error", detail: "All fields have to be filled")
        }
    }
    
    @IBAction func createTable(sender: AnyObject) {
        if checkContentFields() == true {
            createView.hidden = false
            UIView.animateWithDuration(2, animations: {
                self.createView.frame = CGRectMake((UIScreen.mainScreen().bounds.width / 2) - 150, (UIScreen.mainScreen().bounds.height / 2) - (380 / 2), 300, 380)
            })
            print("size view anim: \(createView.frame.size)")
        }
    }
    
    
    func checkContentFields() -> Bool {
        if nicknameField.text != "" && ipTextField.text != "" && portTextField.text != "" {
            return true
        }
        return false
    }
    
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showListTable" {
            let vc: ListTableViewController = (segue.destinationViewController as? ListTableViewController)!

            vc.listTable = listTable
            vc.selfClient = sender as? Client
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("LabelCellIdentifier") as! LabelTableViewCell
        
        cell.label.text = createView.blindsString[indexPath.row]
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        createView.blindLabel.text = createView.blindsString[indexPath.row]
        createView.showListBlind(1)
    }
    
    
    
    override func shouldAutorotate() -> Bool {
        return false
    }

}

